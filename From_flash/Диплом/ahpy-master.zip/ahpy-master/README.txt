Docs are in the "doc" directory in rst format.

To get other formats such as html:

1) install sphinx,
2) go to "doc" directory,
3) and run "make html".
