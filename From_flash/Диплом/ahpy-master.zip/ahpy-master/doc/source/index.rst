.. Python AHP library documentation master file, created by
   sphinx-quickstart on Tue Apr  6 22:21:37 2010.

Welcome to Python AHP library's documentation!
==============================================

Contents:

.. toctree::
   :maxdepth: 2

   introduction.rst
   usage.rst
   modules.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

